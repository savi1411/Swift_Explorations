/*:
## Treinamento em desenvolvimento iOS - 1ª Revisão
 
 A revisão será efetuada através de exercícios práticos.
 
  Os seguintes itens da linguagem Swift serão cobertos:
 
- `Nomenclatura e Identificadores`
- `Constantes e Variáveis`
- `Strings`
- `Funções`
- `Tipos`
- `Parâmetros e Resultados`
 
 página 1 of 7  |  [Próximo: Nomenclatura e Identificadores](@next)
 */
