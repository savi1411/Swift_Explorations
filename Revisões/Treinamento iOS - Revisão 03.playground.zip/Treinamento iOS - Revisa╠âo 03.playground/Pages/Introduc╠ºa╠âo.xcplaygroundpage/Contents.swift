/*:
## Treinamento em desenvolvimento iOS - 3ª Revisão
 
 A revisão será efetuada através de exercícios práticos.
 
  Os seguintes itens da linguagem Swift serão cobertos:
 
- `Estruturas e Classes`
- `Enums`
- `Enums e Switch`
- `Contando Votos com Função`
- `Processando Dados`
 
 página 1 of 6  |  [Próximo: Estruturas e Classes](@next)
 */
